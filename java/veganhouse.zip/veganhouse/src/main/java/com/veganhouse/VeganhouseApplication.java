package com.veganhouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VeganhouseApplication {

	public static void main(String[] args) {
		SpringApplication.run(VeganhouseApplication.class, args);
	}

}
